// Se importan los cosos que se utilizan 

import java.util.Random;
import java.util.Arrays;

public class uso_cartas{

    int contador_pares;
    int contador_tercia;
    int contador_escalera;
    int contador_flor;

    public int get_contador_pares(){ return contador_pares; }
    public int get_contador_tercia(){ return contador_tercia; }
    public int get_contador_escalera(){ return contador_escalera; }
    public int get_contador_flor(){ return contador_flor; }

    public void set_contador_pares(int nuevo_par){ contador_pares = nuevo_par; }
    public void set_contador_tercia(int nuevo_tercia){ contador_tercia = nuevo_tercia; }
    public void set_contador_escalera(int nuevo_escalera){ contador_escalera = nuevo_escalera; }
    public void set_contador_flor(int nuevo_flor){ contador_flor = nuevo_flor; }



    // método que nos dice si hay una flor imperial en el mazo
    public void flor_imperial(String[] palos_cartas, String [] valores_cartas){    
        int contador_flor = 0;
        for(int i=1; i<valores_cartas.length; i++){
            if(palos_cartas[i].equals(palos_cartas[i-1])){
                // Si ya se tiene el palo, ahora se tienen que tener los valores: 1, 10, 11, 12, 13
                if( Arrays.asList(valores_cartas).contains("1") && Arrays.asList(valores_cartas).contains("10") && 
                Arrays.asList(valores_cartas).contains("11") && Arrays.asList(valores_cartas).contains("12") && Arrays.asList(valores_cartas).contains("13") )
                {
                    contador_flor += 1;
                }
            }
        }
        
        this.set_contador_flor(contador_flor);

        if(contador_flor==4){
            System.out.println("Hay una flor imperial en tu juego");
            System.out.println();
        } 
    }


    public void escalera(int[] valores_cartas_int){
        // Se ordenan los valores de las cartas
        Arrays.sort(valores_cartas_int);
        // Se crea un array con los valores de las cartas ordenados
        int[] valores_ordenados_int = valores_cartas_int;

        int contador_escalera=0;
        for(int i=1; i<valores_ordenados_int.length; i++){
            if(valores_ordenados_int[i] - valores_ordenados_int[i-1] == 1){
                contador_escalera+=1;
            }
        }

        this.set_contador_escalera(contador_escalera);

        if(contador_escalera==4){
            System.out.println("Hay una escalera en tu juego");
            System.out.println();
        }
    }

    
    public void tercia(int[] valores_cartas_int){
    // Se ordenan los valores de las cartas
    Arrays.sort(valores_cartas_int);
    // Se crea un array con los valores de las cartas ordenados
    int[] valores_ordenados_int = valores_cartas_int;

        for(int i=1; i<valores_ordenados_int.length-1; i++){
            if(valores_ordenados_int[i] == valores_ordenados_int[i-1] && valores_ordenados_int[i+1] == valores_ordenados_int[i] )
            {
                set_contador_tercia(1);
            }
        }
       
        if(this.get_contador_tercia()==1){
            System.out.println("Hay una tercia en tu juego");
            System.out.println();
        }
    }


    public void par(int[] valores_cartas_int){
        // Se ordenan los valores de las cartas
        Arrays.sort(valores_cartas_int);
        // Se crea un array con los valores de las cartas ordenados
        int[] valores_ordenados_int = valores_cartas_int;
            // Si hay una tercia, entonces me fijo en los valores que no corresponden a la tercia
            if(valores_ordenados_int[0] == valores_ordenados_int[1] && valores_ordenados_int[1] == valores_ordenados_int[2]){
                if(valores_ordenados_int[3] == valores_ordenados_int[4]){
                    System.out.println("Hay un par en tu juego");
                    System.out.println();
                }
            }
            else if(valores_ordenados_int[2] == valores_ordenados_int[3] && valores_ordenados_int[3] == valores_ordenados_int[4]){
                if(valores_ordenados_int[0]==valores_ordenados_int[1]){
                    System.out.println("Hay un par en tu juego");
                    System.out.println();
                }
            }

            else if(valores_ordenados_int[1] == valores_ordenados_int[2] && valores_ordenados_int[2] == valores_ordenados_int[3]){
                System.out.println();
            }
            else{ 
                int contador_pares=0;
                for(int i=1; i<valores_ordenados_int.length; i++){
                    if(valores_ordenados_int[i] == valores_ordenados_int[i-1]){
                        contador_pares +=1;
                    }
                }

                this.set_contador_pares(contador_pares);

                if(contador_pares==1){
                    System.out.println("Hay un par en tu juego");
                    System.out.println();
                }
                else if(contador_pares==2){
                    System.out.println("Hay dos pares en tu juego");
                    System.out.println();
                }
            }
        }


        public void evaluaMano(String[] palos_cartas, String [] valores_cartas,int[] valores_cartas_int){
            
            this.flor_imperial(palos_cartas, valores_cartas);
            this.escalera(valores_cartas_int);
            this.tercia(valores_cartas_int);
            this.par(valores_cartas_int);

            if(this.get_contador_escalera() !=4 && this.get_contador_flor() !=4 && this.get_contador_pares()==0 && this.get_contador_tercia()==0){
                System.out.println("No tienes juego :( ");
                System.out.println();
            }
        }



        public static void main(String[] args){
        
        // // ######################################### CARTAS RANDOM ################################################# 

        // Lo siguiente es para generar cartas de manera aleatoria
        // Se pueden descomnetar las líneas y el código funciona de igual manera 

        // String[] Palos = {"diamantes", "corazones", "treboles", "pikas"};
        // String[] Valores = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13"};
        
        // Random rand1 = new Random();
        // Random rand2 = new Random();
    
        // // Se hace un array en donde se guardas las cartas que se quiere
        // Carta[] mazo = new Carta [5];

        // for(int i=0; i<mazo.length; i++){
        //     //String palo = "diamantes";
        //     //String valor = "A"

        //     // Se elige un número aleatorio entre 0 y 3
        //     int indice_palos = rand1.nextInt(Palos.length);
        //     // Se elige de manera aleatoria un palo de la baraja
        //     String palo = Palos[indice_palos];

        //     int indice_valores = rand2.nextInt(Valores.length);
        //     String valor = Valores[indice_valores];

        //     // Se guardan las cartas en el array llamado mazo
        //     mazo[i] = new Carta(palo, valor);
        //     mazo[i].detalles();
        // }

        // ############################################################################################################# 

        
        
        // ######################################### CARTAS INTRODUCIDAS POR EL USUARIO ################################

        // El usuario eleige el valor de la carta y el palo de la misma 

        Carta carta1 = new Carta("pikas", "1");
        Carta carta2 = new Carta("pikas", "10");
        Carta carta3 = new Carta("pikas", "12");
        Carta carta4 = new Carta("pikas", "11");
        Carta carta5 = new Carta("pikas", "13");

        Carta[] mazo = {carta1, carta2, carta3, carta4, carta5};

        for(int i=0; i<mazo.length; i++){
            mazo[i].detalles();
        }

        // ############################################################################################################# 

        // Se guardan los valores de cada carta, vistos como String, en un array para después comparar cada elemento y ver si existen las cosas que se piden 
        String[] valores_cartas = new String [mazo.length];
        // Los valores de cada carta se guardan como int 
        int[] valores_cartas_int = new int [mazo.length];
        // Se guardan los palos de cada carta en un array para su uso posterior 
        String[] palos_cartas = new String [mazo.length];
        // En este bucle se guardan los elementos según sea el caso 
        for(int i=0; i<mazo.length; i++){
            valores_cartas[i] = mazo[i].get_valor();
            valores_cartas_int[i] = Integer.parseInt(mazo[i].get_valor()); 
            palos_cartas[i] = mazo[i].get_palo();
        }

        // ################################################## 


        uso_cartas juego = new uso_cartas();
        Arrays.sort(valores_cartas_int);
        // Se crea un array con los valores de las cartas ordenados
        int[] valores_ordenados_int = valores_cartas_int;
        System.out.println("\nLa mano con la que juegas es: " + Arrays.toString(valores_ordenados_int));
        System.out.println();

        // Con esta línea se inicia el juego 
        juego.evaluaMano(palos_cartas, valores_cartas, valores_cartas_int);

    }
}