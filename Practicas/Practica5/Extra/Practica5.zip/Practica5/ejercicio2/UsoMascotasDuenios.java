import java.util.Scanner;

import javax.swing.CellEditor;

import java.util.Random;

public class UsoMascotasDuenios {

	
	// Método que revisa si la mascota está vacunada contra el covid y el sarampión
	public void esta_vacunado(Mascota mascota){
        if(mascota.get_enfermedad_covid() == false){
            System.out.println("La mascota " + mascota.getNombre() + ", cuyo dueño/a es " + mascota.getDuenio().getNombre() + ", SÍ está vacunada contra el COVID");
        }
		else{
			System.out.println("La mascota " + mascota.getNombre() + ", cuyo dueño/a es " + mascota.getDuenio().getNombre() + ", NO está vacunada contra el COVID");
		}

		if(mascota.get_enfermedad_sarampion()== false){
			System.out.println("La mascota " + mascota.getNombre() + ", cuyo dueño/a es " + mascota.getDuenio().getNombre() + ", SÍ está vacunada contra el sarampión");
		}
		else{
			System.out.println("La mascota " + mascota.getNombre() + ", cuyo dueño/a es " + mascota.getDuenio().getNombre() + ", NO está vacunada contra el sarampión");
		}
    }
	

	// Método que nos dice que vacunas se les debe aplicar a las mascotas si es que estas tienen alguna enfermedad 
	public void vacunas_a_aplicar(Duenio duenio){
		if(duenio.getMascota() != null){
			System.out.println("\n¡Hola " + duenio.getNombre() + "!");
			System.out.println("Recuerda que debes vacunar a tu mascota.");
			System.out.println();
			if(duenio.mascota.get_enfermedad_covid() == true){
				System.out.println("Tu mascota tiene COVID, debes vacunarla " );
			}
			
			if(duenio.mascota.get_enfermedad_sarampion()==true){
				System.out.println("Tu mascota tiene sarampión, debes vacunarla");
				System.out.println();
			}
		}
		else{
			System.out.println("El dueño, de nombre " + duenio.getNombre() + ", no tiene mascotas a su cargo ");
		}
	}



	public void adopcion(Mascota mascota){

		Scanner entrada_usuario = new Scanner(System.in);
		System.out.println("\n¿Quieres vacunar a tu mascota? \n1.- Si \n2.- No \n3.- En otro momento");
		int respuesta = entrada_usuario.nextInt();

		// Sí quiere vacunar a su mascota
		if(respuesta == 1){
			
			System.out.println("\nI N D I C A C I O N E S   G E N E R A L E S\n");
			System.out.println("*Hay dos posibles vacunas que se pueden aplicar; COVID y Sarampión");
			System.out.println("*Ten en cuenta que la vacuna del COVID no se puede aplicar si la mascota no está protegida contra el Sarampión");
			System.out.println("*Por protocolo, primero se hace un pequeño diagnóstico para ver si la mascota presenta Sarampión.\n");

			if(mascota.get_enfermedad_sarampion() == false){
				System.out.println("D I A G N Ó S T I C O: La mascota parece no tener Sarampión.");
				System.out.println("Tu mascota sí puede vacunarse contra COVID");
				System.out.println("\n¿Quieres vacunar a tu mascota contra el COVID \n1.- Si \n2.- No");
			
				int tipo_vacuna = entrada_usuario.nextInt();

				switch(tipo_vacuna){
				// Se eligió covid
					case 1:
						mascota.set_enfermedad_covid(false);
						System.out.println("¡Listo!, tu mascota ya fue vacunada contra el COVID");
						break;
					case 2:
						System.out.println("Está bien, pero recuerda que es importante vacunar a tu mascota.");
						System.out.println("Vuelve pronto :)");
						break;
				}
			}
			else{
				System.out.println("D I A G N O S T I C O: La mascota podría tener Sarampión. ");
				System.out.println("Tu mascota no puede vacunarse contra COVID en primera instancia por protocolo");
				System.out.println("Si quieres que tu mascota pueda ser vacunada contra COVID es necesario que primero la vacunes contra el Sarampión.");
				System.out.println("\n¿Quieres vacunar a tu mascota contra Sarampión ? \n1.- Si \n2.- No");

				int respuesta2 = entrada_usuario.nextInt();

				// La quiere vacunar contra el Sarampión
				if(respuesta2 == 1){
					mascota.set_enfermedad_sarampion(false);
					System.out.println("\nPerfecto. Tu mascota ya fue vacunada contra Sarampión\n");
					
					System.out.println("Ahora, ¿quieres vacunar a tu mascota contra COVID? \n1.- Si \n2.- No ");
					int respuesta3 = entrada_usuario.nextInt();

					switch(respuesta3){
					// Se eligió covid
						case 1:
							mascota.set_enfermedad_covid(false);
							System.out.println("¡Listo!, tu mascota ya fue vacunada contra el COVID\n");
							break;
						case 2:
							System.out.println("Está bien, pero recuerda que es importante vacunar a tu mascota.");
							System.out.println("Vuelve pronto :)");
							break;
					}
				}
				else{
					System.out.println("Está bien, pero recuerda, no podrá ser vacunada contra COVID.");
				}
			}
		}
		else if(respuesta==2){
			System.out.println("Recuerda que es muy importante vacunar a tus mascotas.");
		}
		else{
			System.out.println("Vuelve pronto :)");
		}
	}



	public void contraerCovid(Mascota mascota){
		int [] valores = new int[20];
		Random rand1 = new Random();
		int valor1 = rand1.nextInt(valores.length);
		int valor2 = rand1.nextInt(valores.length);
		int valor3 = rand1.nextInt(valores.length);

		System.out.println("\nA T E N C I Ó N\n");
		System.out.println("Existe la posibilidad de que tu mascota contraiga COVID bajo los siguientes porcentajes");
		System.out.println("* Si la mascota está vacunada contra el Sarampión y el COVID tendrá 5% de probabilidad de enfermarse");
		System.out.println("* Si la mascota no tiene la vacuna del COVID pero sí la del Sarampión, tendrá 20% de probabilidad de enfermarse");
		System.out.println("* Si la mascota no está vacunada contra nada, tendrá un 95% de probabilidad de enfermarse");

		System.out.println("\nTu mascota presenta las siguientes vacunas:");
		if(mascota.get_enfermedad_covid()==true ){
			System.out.println("\t*NO tiene vacuna contra COVID");
		}
		
		if(mascota.get_enfermedad_sarampion()==true){
			System.out.println("\t*NO tiene vacuna contra Sarampión");
		}
		
		if(mascota.get_enfermedad_covid()==false){
			System.out.println("\t*SÍ tiene vacuna contra COVID");
		}
		
		if(mascota.get_enfermedad_sarampion()==false){
			System.out.println("\t*SÍ tiene vacuna contra Sarampión\n");
		}


		if(mascota.get_enfermedad_covid() == false && mascota.get_enfermedad_sarampion() == false){
			// Esto representa el 5%
			if(valor1 == 1){
				System.out.println("\nTu mascota se contagió de COVID, :(");
				mascota.set_enfermedad_covid(true);
			}
			else{
				System.out.println("\nTu mascota no se contagió :)");
			}
		}
		else if(mascota.get_enfermedad_covid()==true && mascota.get_enfermedad_sarampion()==false){
			// Esto representa el 20%
			if(valor2==1 || valor2 == 2 || valor2 == 3 || valor2 == 4){
				System.out.println("\nTu mascota se contagió de COVID, :(");
				mascota.set_enfermedad_covid(true);
			}
			else{
				System.out.println("\nTu mascota no se contagió :)");
			}
		}
		else if(mascota.get_enfermedad_covid() == true && mascota.get_enfermedad_sarampion() == true){
			// Esto representa el 95%
			if(valor3 != 1){
				System.out.println("\nTu mascota se contagió de COVID, :(");
				mascota.set_enfermedad_covid(true);
			}
			else{
				System.out.println("\nTu mascota no se contagió :)");
			}
		}
	}


	public void sanar(Mascota mascota){
		System.out.println("\nTu mascota ya se siente mejor :) ");
		System.out.println("Ya no tiene enfermedades :') \n");
		mascota.set_enfermedad_covid(false);
		mascota.set_enfermedad_sarampion(false);
	}


	public void convivir(Mascota mascota1, Mascota mascota2){
		if(mascota1.get_enfermedad_covid()==false && mascota1.get_enfermedad_sarampion()==false 
		&& mascota2.get_enfermedad_covid()==false && mascota2.get_enfermedad_sarampion()==false){
			System.out.println("Las mascotas están sanas, no tienen ninguna enfermedad, por lo que están jugando libremente");
		}
		
		if(mascota1.get_enfermedad_covid()==true || mascota1.get_enfermedad_sarampion()==true){
			System.out.println("C U I D A D O: La mascota " + mascota1.getNombre() + " está enferma");
			if(mascota1.get_enfermedad_covid()==true && mascota1.get_enfermedad_sarampion()==true){
				System.out.println("La mascota " + mascota1.getNombre() + " tiene COVID y Sarampión por lo que al estar conviviendo con " + mascota2.getNombre() + " la contagió");
				mascota2.set_enfermedad_covid(true);
				mascota2.set_enfermedad_sarampion(true);
			}
			else if(mascota1.get_enfermedad_covid()==true){
				System.out.println("La mascota " + mascota1.getNombre() + " tiene COVID por lo que al estar conviviendo con " + mascota2.getNombre() + " la contagió");
				mascota2.set_enfermedad_covid(true);
			}
			else if(mascota1.get_enfermedad_sarampion()==true){
				System.out.println("La mascota " + mascota1.getNombre() + " tiene Sarampión por lo que al estar conviviendo con " + mascota2.getNombre() + " la contagió");
				mascota2.set_enfermedad_sarampion(true);
			}
		}
		else if(mascota2.get_enfermedad_covid()==true || mascota2.get_enfermedad_sarampion()==true){
			System.out.println("C U I D A D O: La mascota " + mascota2.getNombre() + " está enferma");
			if(mascota2.get_enfermedad_covid()==true && mascota2.get_enfermedad_sarampion()==true){
				System.out.println("La mascota " + mascota2.getNombre() + " tiene COVID y Sarampión por lo que al estar conviviendo con " + mascota1.getNombre() + " la contagió");
				mascota1.set_enfermedad_covid(true);
				mascota1.set_enfermedad_sarampion(true);
			}
			else if(mascota2.get_enfermedad_covid()==true){
				System.out.println("La mascota " + mascota2.getNombre() + " tiene COVID por lo que al estar conviviendo con " + mascota1.getNombre() + " la contagió");
				mascota1.set_enfermedad_covid(true);
			}
			else if(mascota2.get_enfermedad_sarampion()==true){
				System.out.println("La mascota " + mascota2.getNombre() + " tiene Sarampión por lo que al estar conviviendo con " + mascota1.getNombre() + " la contagió");
				mascota1.set_enfermedad_sarampion(true);
			}
		}

	}



	public static void main(String[] args) {
		
		Vacuna vacuna_covid = new Vacuna("SanaSana", "covid");
		Vacuna vacuna_sarampion = new Vacuna("SanaSana", "sarampion");


		// Se crea el dueño y sus mascotas
		Duenio duenio1 = new Duenio("Martha");
		Mascota mascota1 = new Mascota("Turing" , "pez", duenio1, false, true);

		Duenio duenio2 = new Duenio("Juan");
		Mascota mascota2 = new Mascota("Chopper", "venado", duenio2, false, false);


		// Se están creando dos personas con sus mascotas resp.
		duenio1.setMascota(mascota1);
		duenio2.setMascota(mascota2);
		//System.out.println(mascota1);
		//System.out.println(mascota2);


		UsoMascotasDuenios chequeo = new UsoMascotasDuenios();
	
		//chequeo.adopcion(mascota2);
		// // Esto es para ver si sí están vacunadas las mascotas 
		// chequeo.esta_vacunado(mascota1);
		// chequeo.esta_vacunado(mascota2);

		// chequeo.vacunas_a_aplicar(duenio1);
		// chequeo.vacunas_a_aplicar(duenio2);

		// chequeo.contraerCovid(mascota2);
		// chequeo.sanar(mascota2);

		//chequeo.convivir(mascota1, mascota2);

		mascota1.detalles_mascota();
		mascota2.detalles_mascota();






	}



}

