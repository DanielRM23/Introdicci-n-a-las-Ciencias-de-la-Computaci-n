public class Vacuna{

    // Estos son los atributos de la vacuna
    String marca;
    // Esta es la enfermedad que ataca 
    String enfermedad;


    // Se hacen los gets 
	public String get_marca(){return marca;}
    public String get_enfermedad(){return enfermedad;}

    public void set_marca(String nueva_marca){marca = nueva_marca;}
    public void set_enfermedad(String nueva_enfermedad){enfermedad = nueva_enfermedad; }
  
  
    public Vacuna(String marca, String enfermedad){}


}