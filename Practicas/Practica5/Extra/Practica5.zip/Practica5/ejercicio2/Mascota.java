
public class Mascota {
	
	String nombre;
	String especie;
	Duenio d;
	boolean enfermedad_covid;
	boolean enfermedad_sarampion;

	//Constructor
	public Mascota(String n, String e, Duenio d, boolean enfermedad_covid, boolean enfermedad_sarampion) {
		nombre = n;
		especie = e;
		this.d = d;
		this.enfermedad_covid = enfermedad_covid;
		this.enfermedad_sarampion = enfermedad_sarampion;
	}

	// Se hacen los sets
	public void setNombre(String n){nombre = n;}
	public void setEspecie(String e){especie = e;}
	public void setDuenio(Duenio d){this.d = d;}
	public void set_enfermedad_covid(boolean nueva_enfermedad_covid){enfermedad_covid = nueva_enfermedad_covid;}
	public void set_enfermedad_sarampion(boolean nueva_enfermedad_sarampion){enfermedad_sarampion = nueva_enfermedad_sarampion;}


	// Se hacen los gets 
	public String getNombre(){return nombre;}
	public String getEspecie(){return especie;}
	public Duenio getDuenio(){return d;}
	public boolean get_enfermedad_covid(){return enfermedad_covid;}
	public boolean get_enfermedad_sarampion(){return enfermedad_sarampion;}


	public void saludaMascota() {
		System.out.println("Estas en la clase Mascota");
	}


	public void detalles_mascota(){
		System.out.println("\nI N F O R M A C I Ó N  D E  L A  M A S C O T A\n");
		System.out.println("*Nombre del dueño: " + this.d.getNombre() );
		System.out.println("*Nombre de la mascota: " + this.getNombre() );
		System.out.println("*Especie: " + this.getEspecie());
		System.out.println("*Enfermedades: ");

		if(this.get_enfermedad_covid()==true){
			System.out.println("\t*COVID: Si");
		}
		else if(this.get_enfermedad_covid()==false){
			System.out.println("\t*COVID: No");
		}
		
		if(this.get_enfermedad_sarampion()==true){
			System.out.println("\t*Sarampión: Si");
		}
		else if(this.get_enfermedad_sarampion()==false){
			System.out.println("\t*Sarampión: No");
		}

		System.out.println();
	}

	
	public String toString() {
		String cad="";

		if(d != null) {
			if(d.getNombre()!= null){
				cad = "Soy la mascota " + especie + " de nombre " + nombre + " y mi dueño es " + d.getNombre();
			} 
			else{
				cad = "Soy la mascota " + especie + " de nombre " + nombre + " y no tengo dueño"; 
			}
		} 
		else{
			cad = "Soy la mascota " + especie + " de nombre " + nombre + " y mi dueño no existe"; 
		}
		return cad;
	}
}


