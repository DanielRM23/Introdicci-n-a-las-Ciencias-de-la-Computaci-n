
// Se crea la excepcion 
public class CapacidadInsuficiente extends Exception{
    public CapacidadInsuficiente(String mensaje){        
        super(mensaje);
    }
}