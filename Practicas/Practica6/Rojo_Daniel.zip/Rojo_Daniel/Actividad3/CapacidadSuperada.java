
// Se crea la excepcion 
public class CapacidadSuperada extends Exception{    
    public CapacidadSuperada(String mensaje){
        super(mensaje);
    }  
}