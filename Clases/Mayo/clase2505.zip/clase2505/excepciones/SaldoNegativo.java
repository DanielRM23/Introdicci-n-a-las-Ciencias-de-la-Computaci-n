
public class SaldoNegativo extends Exception {
	
	public SaldoNegativo(String mensaje) {
		super(mensaje);
	}


}
